package com.magadhUniversity.controller;
import com.magadhUniversity.model.Timetable;
import com.magadhUniversity.service.TimetableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping("/timetables")
public class TimetableController {

    @Autowired
    private TimetableService timetableService;


    // Endpoint to render student timetable page
    @GetMapping("/studentview")
    public String studentTimetablePage() {
        return "student-timetable";  // Return student timetable Thymeleaf template
    }
    // Endpoint to get timetable for a specific day (Student view)
    @GetMapping("/studentview/day/{day}")
    @ResponseBody
    public List<Timetable> getTimetableForDay(@PathVariable("day") String day) {
        return timetableService.getTimetableForDay(day);
    }


    // Endpoint to add a new timetable (Employee - POST)
//    @GetMapping("/add")
//    public String addTimetableForm(Model model) {
//        model.addAttribute("timetable", new Timetable());
//        return "add-timetable";  // Render form to add new timetable
//    }
    @PostMapping("/add")
    public String addTimetableForm(@RequestBody Timetable timetable) {
        try {
            timetableService.addTimetable(timetable);
            return "Timetable added successfully!";
        } catch (Exception e) {
            return "Error adding timetable: " + e.getMessage();
        }
    }



    @PostMapping("/add")
    public String addTimetable(@ModelAttribute Timetable timetable) {
        timetableService.addTimetable(timetable);  // Call service to save timetable
        return "redirect:/timetables/list";  // Redirect to list all timetables
    }


    // Endpoint to list all timetables (Employee view)
    @GetMapping("/list")
    public String listTimetables(Model model) {
        List<Timetable> timetables = timetableService.getAllTimetables();
        model.addAttribute("timetables", timetables);
        return "list-timetable";  // Render all timetables
    }

    // Endpoint to edit a timetable (Employee - GET)
    @GetMapping("/edit/{id}")
    public String editTimetableForm(@PathVariable("id") Long id, Model model) {
        Timetable timetable = timetableService.getTimetableById(id);
        model.addAttribute("timetable", timetable);
        return "edit-timetable";  // Render form to edit timetable
    }

    // Endpoint to update a timetable (Employee - POST)
    @PostMapping("/edit/{id}")
    public String editTimetable(@PathVariable("id") Long id, @ModelAttribute Timetable timetable) {
        timetable.setId(id);
        timetableService.updateTimetable(timetable);  // Call service to update timetable
        return "redirect:/timetables/list";  // Redirect to list all timetables
    }

    // Endpoint to delete a timetable (Employee)
    @GetMapping("/delete/{id}")
    public String deleteTimetable(@PathVariable("id") Long id) {
        timetableService.deleteTimetable(id);  // Call service to delete timetable
        return "redirect:/timetables/list";  // Redirect to list all timetables
    }
}