package com.magadhUniversity.repository;

import com.magadhUniversity.model.Timetable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface TimetableRepository extends JpaRepository<Timetable, Long> {

    // Custom query to fetch timetable by day
    List<Timetable> findByDay(String day);
}