package com.magadhUniversity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HrmsAttendanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrmsAttendanceApplication.class, args);
	}

}
