package com.magadhUniversity.service;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface CustomUserDetailsService extends UserDetailsService {
    // You can add any additional methods if needed
}
