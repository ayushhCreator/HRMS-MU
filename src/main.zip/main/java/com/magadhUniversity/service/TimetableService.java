package com.magadhUniversity.service;

import com.magadhUniversity.model.Timetable;
import com.magadhUniversity.repository.TimetableRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TimetableService {

    @Autowired
    private TimetableRepository timetableRepository;

    // Get timetable for a specific day
    public List<Timetable> getTimetableForDay(String day) {
        return timetableRepository.findByDay(day);
    }

    // Get all timetables
    public List<Timetable> getAllTimetables() {
        return timetableRepository.findAll();
    }

    // Add new timetable
    public void addTimetable(Timetable timetable) {
        timetableRepository.save(timetable);
    }

    // Get timetable by ID
    public Timetable getTimetableById(Long id) {
        return timetableRepository.findById(id).orElseThrow(() -> new RuntimeException("Timetable not found"));
    }

    // Update timetable
    public void updateTimetable(Timetable timetable) {
        timetableRepository.save(timetable);
    }

    // Delete timetable
    public void deleteTimetable(Long id) {
        timetableRepository.deleteById(id);
    }
}